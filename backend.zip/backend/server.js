const express = require('express');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// In-memory blog store (temporary)
const blogPosts = [
  { title: 'My First Post', body: 'Hello World!' },
  { title: 'Another Post', body: 'lorem ipsum modda gudu' }
];

// GET /api/blog-list
app.get('/api/blog-list', (req, res) => {
  res.json(blogPosts);
});

// POST /api/blog-post
app.post('/api/blog-post', (req, res) => {
  const { title, body } = req.body;
  if (!title || !body) {
    return res.status(400).json({ error: 'Missing title or body' });
  }

  const newPost = { title, body };
  blogPosts.push(newPost);

  console.log("✅ Blog post added:", newPost);
  res.status(201).json({
    success: true,
    message: 'Blog post created!',
    data: newPost
  });
});

// GET /api/profile
app.get('/api/profile', (req, res) => {
  res.json({
    Profile: {
      name: 'Alice',
      role: 'Student'
    }
  });
});

// GET /api/greet
app.get('/api/greet', (req, res) => {
  const name = req.query.name?.trim();
  if (name) {
    return res.json({ greeting: `Hello, ${name}!` });
  } else {
    return res.json({ greeting: 'Hello there!' });
  }
});

// Home route
app.get('/', (req, res) => {
  res.send('Welcome to the Blog API 🚀');
});

// 404 fallback
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`🚀 Server listening at http://localhost:${PORT}/`);
});
