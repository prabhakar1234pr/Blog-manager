// controllers/blogController.js

const createBlogPost = (req, res) => {
    const { title, body } = req.body;

    if (title && body) {
        return res.json({
            success: true,
            title,
            body
        });
    } else {
        return res.status(400).json({
            error: 'Missing title or body.'
        });
    }
};
exports.createBlogPost = createBlogPost;


