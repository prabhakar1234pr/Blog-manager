// controllers/blogListController.js

const getBlogList = (req, res) => {
    const dummyBlogPosts = [
      { title: 'My First Post', body: 'Hello World!' },
      { title: 'Another Post', body: 'lorem ipsum modda gudu' }
    ];
    res.json(dummyBlogPosts);
  };
  
  module.exports = getBlogList;
  