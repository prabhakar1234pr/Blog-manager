import React, { useState } from 'react';
import "./BlogBody.css";

function BlogBody() {
  const [title, setTitle] = useState('');
  const [posts, setPosts] = useState([]);
  const [body, setBody] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  function handleDeletePost(indexToRemove) {
    const confirmed = window.confirm("Are you sure you want to delete this post?");
    if (!confirmed) return;

    const updatedPosts = posts.filter((_, index) => index !== indexToRemove);
    setPosts(updatedPosts);
  }

  function handleTitleChange(event) {
    setTitle(event.target.value);
  }

  function handleBodyChange(event) {
    setBody(event.target.value);
  }

  async function handlePost() {
    if (title.trim() === '') {
      alert('Please enter a title');
      return;
    }

    const newPost = {
      title,
      body,
      date: date || new Date().toLocaleDateString(),
      time: time || new Date().toLocaleTimeString()
    };

    try {
      console.log('Sending blog post to backend:', newPost);

      const response = await fetch('http://localhost:3001/api/blog-post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: newPost.title,
          body: newPost.body
        })
      });

      const data = await response.json();
      console.log('Response from backend:', data);
      if(data.success){
        setStatusMessage(`Blog post "${newPost.title}" successfully saved to server`);
        setTimeout(()=> setStatusMessage(''),5000);
      }else{
        setStatusMessage('Server returned an unexpected response');
        setTimeout(()=> setStatusMessage(''),5000);
      }

      setPosts([...posts, newPost]);
      setTitle('');
      setBody('');
      setDate('');
      setTime('');
    } catch (error) {
      console.error('Error sending blog post to API:', error);
      const errorMessage = {
        title: 'Sorry, there was an error communicating with the blog post.Please try again.',
        body: 'Sorry,there was an error communicating with the blog post.Please try again',
        timestamp: new Date().toLocaleString()
      };
    }
  }

  return (
    <main>
      <h2>Create a New Blog Post</h2>
      <p>{statusMessage}</p>
      <form>
        <label>
          Title:
          <input
            type="text"
            value={title}
            onChange={handleTitleChange}
            placeholder="Title of my awesome post"
          />
        </label>
        <br /><br />

        <p>This information is Confidential.</p>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
        <br /><br />
        <label>
          Body:
          <textarea
            name="body"
            value={body}
            onChange={handleBodyChange}
            placeholder="Write your blog content here..."
          ></textarea>
        </label>
        <br /><br />
        <div className="button-group">
          <button className="blogbutton" type="button" onClick={handlePost}>Post</button>
        </div>
      </form>

      <hr />
      <h3>Posted Titles:</h3>
      {posts.length === 0 ? (
        <p>No posts yet. Start typing!</p>
      ) : (
        posts.map((post, index) => (
          <div key={index}>
            <h4>{post.title}</h4>
            <p>{post.body}</p>
            <p>Blog Posted at {post.date}, {post.time}</p>
            <button onClick={() => handleDeletePost(index)}>Delete</button>
          </div>
        ))
      )}
    </main>
  );
}

export default BlogBody;

