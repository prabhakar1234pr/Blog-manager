import React  from "react";

function Contact(){
    return(
        <div style = {{padding : '1rem'}}>
            <h2>contact</h2>
            <p>Email: prabhakarpr554@gmail.com</p>
            <p>Feel free to reach out!</p>
        </div>
    );
    
}

export default Contact;
