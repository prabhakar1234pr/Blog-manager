import React, { useState, useEffect } from "react";

function BlogPosts() {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchBlogs() {
      try {
        const response = await fetch('http://localhost:3001/api/blog-list');
        const data = await response.json();
        console.log("Fetched blog list:", data);
        setBlogs(data);
      } catch (error) {
        console.error("Error fetching blog list:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchBlogs();
  }, []);

  return (
    <div style={{ padding: "1rem" }}>
      <h2>Blog Posts</h2>
      {loading ? (
        <p>Loading blog posts...</p>
      ) : blogs.length === 0 ? (
        <p>No blog posts found.</p>
      ) : (
        <ul>
          {blogs.map((blog, index) => (
            <li key={index} className="blog-item">
              <h3>{blog.title}</h3>
              <p>{blog.body}</p>
            </li>
          ))}
        </ul>
      )}
      <p>Number of blog posts: {blogs.length}</p>
    </div>
  );
}

export default BlogPosts;

