import React, { useEffect, useState } from "react";

function Profile() {
  const [username, setUsername] = useState('');
  const [role, setRole] = useState('');

  useEffect(() => {
    async function fetchProfile() {
      try {
        const response = await fetch('http://localhost:3001/api/profile');
        const data = await response.json();
        console.log('Fetched profile data:', data);
        
        // Assuming API returns: { Profile: { name: 'Alice', role: 'Student' } }
        setUsername(data.Profile.name);
        setRole(data.Profile.role);
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    }

    fetchProfile();
  }, []);

  return (
    <div style={{ padding: '1rem' }}>
      <h2>Profile</h2>
      {username && role ? (
        <p>Welcome {username}! Your role is: {role}</p>
      ) : (
        <p>Loading profile...</p>
      )}
    </div>
  );
}

export default Profile;

